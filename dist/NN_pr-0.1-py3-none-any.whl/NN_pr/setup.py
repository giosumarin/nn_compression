from setuptools import setup

setup(name='NN_pr',
      version='0.1',
      description='nn_compression',
      url='https://github.com/giosumarin/nn_compression',
      author='giosumarin',
      author_email='xx@xx.com',
      license='MIT',
      packages=['NN_pr'],
      zip_safe=False)
